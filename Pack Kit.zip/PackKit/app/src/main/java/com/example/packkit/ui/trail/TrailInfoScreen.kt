package com.example.packkit.ui.trail

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import java.time.format.DateTimeFormatter
import kotlin.reflect.KProperty1


@Composable
fun TrailInfoScreen(navController: NavController, trip: TripData, modifier: Modifier) {
    val trip = trip

    Column {
        Header(trip, modifier)
        Body(trip, modifier)
    }
}

@Composable
fun Header(trip: TripData, modifier: Modifier) {
    Column(modifier = Modifier
        .background(color = MaterialTheme.colorScheme.primaryContainer)
        .padding(20.dp)
    ) {
        Text(
            text = "Trail Info: ${trip.trip}",
            modifier = Modifier
                .fillMaxWidth(),
            style = MaterialTheme.typography.headlineLarge,
            color = MaterialTheme.colorScheme.onPrimaryContainer
        )
        Text(
            text = trip.date
                .format(DateTimeFormatter.ofPattern("MMMM dd , yyyy")),
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onPrimaryContainer
        )
    }
}

@Composable
fun Body(trip: TripData, modifier: Modifier) {
    val titleList = listOf("Distance", "Elevation Gain", "Permits", "Reports", "Notes", "Gear")
    val scrollState = rememberLazyListState()
    LazyColumn(
        state = scrollState,
        modifier = Modifier
    ) {
        items(titleList) { title ->
            BodyCard(title, trip)
        }
    }
}

@Composable
fun BodyCard(title: String, trip: TripData) {
    Column(
        modifier = Modifier
            .padding(20.dp)
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleLarge
        )

        if (title == "Permits") {
            RadioButton(
                selected = trip.isPermit,
                onClick = {}
            )
        } else {
            Text(
                text = when (title) {
                    "Distance" -> "${trip.distance}mi"
                    "Elevation Gain" -> "${trip.eleGain}ft"
                    "Reports" -> trip.report
                    "Notes" -> trip.notes
                    "Gear" -> "Placeholder"
                    else -> "No Value Found"
                },
                style = MaterialTheme.typography.bodyLarge
            )
        }
    }
}